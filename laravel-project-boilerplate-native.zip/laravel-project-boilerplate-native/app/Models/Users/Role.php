<?php

namespace App\Models\Users;

use Laratrust\Models\LaratrustRole;
use Illuminate\Database\Eloquent\Model;

class Role extends LaratrustRole {
    //
}
