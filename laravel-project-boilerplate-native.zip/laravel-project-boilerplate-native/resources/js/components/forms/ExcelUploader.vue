<template>
    <span>
        <button class="btn btn-sm btn-primary" @click="$refs.input.click()">
            <i class="fa fa-upload mr-1"></i> <span v-text="text"></span>
        </button>
        <input hidden type="file" :id="id" ref="input" @change="upload" />
    </span>
</template>
<script>
import mixins from 'utils/mixins';
import Form from 'models/components/Form'

export default {
    name: 'ExcelUploader',
    computed: {
        id() {
            return `excel-uploader-${ this._uid }`;
        },
        domSelector() {
            return `#${ this.id }`;
        }
    },

    data: () => ({
        link: "#",
    }),

    methods: {
        upload() {
            if (!this.$refs.input.files.length) {
                return;
            }
            let form = new Form({
                excel: Form.fileListToArray(this.$refs.input.files),
            });
            form.sendPost(this.link, true)
                .then(response => {
                    this.promptSuccess(response.data.message);
                    this.$emit('uploaded', response);
                })
                .catch(error => {
                    this.promptErrors(error.response.data.message);
                    this.$emit('uploa-failed', error);
                });
        },
    },
    mixins: [mixins],
    props: {
        url: String,
        text: String,
    },

    mounted() {
        this.link = this.url || this.link;
    }
}
</script>