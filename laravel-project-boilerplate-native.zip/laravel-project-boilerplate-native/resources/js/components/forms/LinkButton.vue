<template>
    <a :href="link" class="">
        <slot></slot>
    </a>
</template>
<script>
export default {
    name: 'LinkButton',
    computed: {
        link() {
            return route(this.route, this.params)
        }
    },
    props: {
        route: String,
        params: String|Object|Number|Array,
    },
}
</script>