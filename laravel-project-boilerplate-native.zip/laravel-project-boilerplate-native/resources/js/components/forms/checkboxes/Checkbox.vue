<template>
    <div class="custom-control custom-checkbox">
        <input class="custom-control-input" type="checkbox"
            :id="id"
            :checked.sync="value"
            :disabled="disabled"
            @change="change"
        />
        <label class="custom-control-label" :for="id" v-text="label"></label>
    </div>
</template>
<script>
export default {
    name: 'Checkbox',
    computed: {
        id() {
            return `checkbox-${ this._uid }`;
        }
    },

    data() {
        return {
            data: this.value,
        }
    },

    methods: {
        change(event) {
            this.$emit("change", this.data = event.target.checked);
            this.$emit("input", this.data = event.target.checked);
        },
    },

    props: {
        disabled: {
            type: Boolean,
            default: false,
        },
        label: {
            type: String,
            default: "",
        },
        value: {
            type: Boolean,
        },
    }
}
</script>