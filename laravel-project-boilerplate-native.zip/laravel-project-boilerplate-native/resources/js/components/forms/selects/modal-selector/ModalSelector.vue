<template>
    <div>
        <form-input :placeholder="placeholder" :label="label" :value="displayedValue"
            ref="field" autocomplete="off" @focus="showModal"></form-input>
        <modal v-model="modalShown" :title="title" @hidden="onHide" :small="false">
            <div class="row">
                <div class="col-sm-12">
                    <form-input v-model="needle" @input="initSearch" placeholder="Search" ></form-input>
                </div>
            </div>
            <div class="row bg-translucent-neutral">
                <modal-selector-option v-for="option in options" :key="option[valueKey]"
                    @select="toggleOption" :value="option"
                    :display-name="option.fullname"
                    :sub-name="'Resident'"
                    :is-selected="isSelected(option)"
                >
                </modal-selector-option>
                <div v-if="fetching" class="col-sm-12 text-center">
                    <i class="fa fa-spinner fa-spin pr-1"></i>
                    Loading data, please wait ...
                </div>
            </div>
        </modal>
    </div>
</template>
<script>
import { mixins } from 'utils/mixins';
import ModalSelectorOption from './ModalSelectorOption';

export default {
    name: 'ModalSelector',
    computed: {
        displayedValue() {
            return this.selected.map(item => item.display_name).join(', ');
        },
    },
    data: () => ({
        error: "",
        link: '',
        fetching: true,
        pagination: { next_page_url: true },
        data: [],
        modalShown: false,
        selected: [],
        needle: "",
        searchTimeout: null,
        options: [],
    }),

    methods: {

        closeModal() {
            return this.modalShown = false;
        },

        isSelected(option) {
            return this.indexOfOption(option) >= 0;
        },

        onHide() {
            this.modalShown = false;
        },

        showModal() {
            this.modalShown = true;
        },

        initSearch() {
            clearTimeout(this.searchTimeout)
            this.searchTimeout = setTimeout(() => {
                this.clearOptions();
                this.search();
            }, 1000);
        },

        search(values = []) {
            this.fetching = true;
            axios.get(this.link, { params: { ...this.params, search: this.needle }})
                .then(response => this.mapResponse(response, values))
                .catch(error => this.fetchFailed(error))
                .finally(() => this.fetching = false);
        },

        clearOptions() {
            this.options = [];
        },
        
        isNearToBottom(table) {
            return table.scrollTop + table.clientHeight > table.scrollHeight - 100;
        },
        
        loadNewData(event) {
            let table = event.target;
            if (this.fetching || !this.hasMore || !this.isNearToBottom(table))  {
                return;
            }
            this.fetchData();
        },

        getPaginationData(response) {
            this.paginatePath.split('.')
                .forEach(index => response = response[index]);
            return response;
        },

        mapResponse(response, value = []) {
            this.pagination =this.getPaginationData(response);
            this.options.push(...this.pagination.data);
            if (value.length > 0) {
                let selectedOptions = this.pagination.data.filter(item => value.indexOf(item[this.valueKey]) >= 0);
                this.selected.push(...selectedOptions);
                this.$emit('input', this.multiple
                    ? this.selected.map(item => item[this.valueKey])
                    : this.selected[0][this.valueKey]);
            }
        },

        fetchFailed(error) {
            this.promptErrors(error.response.data.message);
        },
        
        movePage(event) {
            event.preventDefault();
            this.link = event.target.href
            this.currentPage = parseInt(event.target.dataset.page)
            this.fetchData();
        },

        toggleOption(option) {
            if (this.multiple|| !option.selected || (option.selected && !this.multiple && this.selected.length < 1)) {
                option.selected
                    ? this.selected.push(option.value)
                    : this.indexOfOption(option.value) >= 0
                        ? this.selected.splice(this.indexOfOption(option.value), 1) : "";
            } else if (!this.multiple && this.selected.length >= 1) {
                option.component.selected = false;
            }

            let value = this.multiple
                ? this.selected.map(i => i[this.valueKey])
                : (option.selected ? this.selected[0][this.valueKey] : "");
            this.$emit('input', value);
            if (!this.multiple && this.selected.length == 1) {
                return this.closeModal();
            }
        },

        indexOfOption(option) {
            if (typeof option != 'object') {
                return this.selected.indexOf(option)
            }
            for (const key in this.selected) {
                if (this.selected[key][this.valueKey] == option[this.valueKey]) {
                    return key;
                }
            }
            return -1;
        },
        
        initializeValue() {
            this.search(this.initialValue);
        }

    },

    mixins: [ mixins ],

    props: {
        value: Array|Number|String|Object,
        title: String,
        label: String,
        placeholder: String,
        fetchLink: String,
        paginatePath: String,
        params: Object,
        multiple: {
            type: Boolean,
            default: false,
        },
        valueKey: {
            type: String,
            default: () => "id"
        },
        initialValue: Array,
    },

    watch: {
        modalShown(newValue) {
            if (!newValue) {
                return;
            }
            this.clearOptions();
            this.search();
        },

        error() {
            this.$nextTick(() => this.$refs.field.error = this.error);
        }
    },

    mounted() {
        this.link = this.fetchLink;
        if (this.initialValue) {
            this.initializeValue();
        }
    }
}
</script>