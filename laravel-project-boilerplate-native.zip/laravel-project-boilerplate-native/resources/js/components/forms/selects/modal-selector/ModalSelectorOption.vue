<template>
    <div class="col-lg-4 col-md-6 col-sm-12 modal-select-option">
        <div class="row pane">
            <div class="col-auto">
                <input type="checkbox" v-model="selected" ref="checkbox"/>
            </div>
            <div class="col">
                <h4 class="display-name" v-text="displayName"></h4>
                <span class="text-muted sub-name" v-text="subName"></span>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    name: 'ModalSelectorOption',

    data: () => ({
        selected: false,
    }),

    methods: {
        change() {
            this.$emit('select', this.selected)
        }
    },

    watch: {
        selected() {
            this.$nextTick(() => {
                if (this.isSelected == this.selected) {
                    return;
                }
                this.$emit('select', {
                    component: this,
                    value: this.value,
                    selected: this.selected,
                })
            });
        }
    },

    props: {
        displayName: String,
        subName: String,
        image: String,
        value: Object|Array|Number|String,
        isSelected: Boolean,
    },
    mounted() {
        this.selected = this.isSelected;
    }
}
</script>