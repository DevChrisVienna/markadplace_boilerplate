<template>
    <div :class="styleClass.formGroup">
        <label v-if="label" :for="id" class="form-control-label ucwords" v-text="label"></label>
        <multiselect :id="id"
            v-model="data"
            :placeholder="placeholder"
            :options="dataOptions"
            :searchable="searchable"
            :max-height="150"
            @select="onChange"
            @remove="onRemove"
            :custom-label="displayedValue"
            :allow-empty="allowEmpty"
            :deselect-label="deselectLabel"
        >
            <template slot="singleLabel" slot-scope="{ option }">
                <slot name="displayedValue" :option="option">
                    <span class="option__title" v-text="displayedValue(option)"></span>
                </slot>
            </template>
            
        </multiselect>
        <span v-if="hasError" class="text-danger" v-text="errorMessage"></span>
    </div>
</template>
<script>
import Multiselect from 'vue-multiselect';
export default {
    name: 'FormSelect',
    components: { Multiselect },

    computed: {

        deselectLabel() {
            return this.allowEmpty
                ? "Press enter to remove"
                : "Can't remove this value";
        },
        id() {
            return `form-select-${ this._uid }`;
        },

        errorMessage() {
            return Array.isArray(this.error) ? this.error[0] : this.error;
        },

        hasError() {
            return this.error
                && (!this.isArrayAnEmptyString()
                || this.isArrayAnEmptyArray());
        },

        styleClass() {
            return {
                formGroup: {
                    'form-group': true,
                    'has-danger': this.hasError,
                    'form-group-disabled': this.disabled,
                },
            }
        },
    },

    data() {
        return {
            data: "",
            error: "",
            dataOptions: this.options,
        }
    },

    methods: {

        clearError() {
            this.error = null;
        },

        displayedValue(option) {
            return (typeof(option) === 'object' ? option[this.textKey] : option);
        },
        
        isArrayAnEmptyArray() {
            return Array.isArray(this.error)
                && !this.error.length;
        },
        
        isArrayAnEmptyString() {
            return typeof this.error === "string"
                && !this.error.trim().length;
        },

        onChange(data) {
            data = typeof(data) === 'object' && data[this.valueKey] !== undefined
                ? data[this.valueKey] : data;
            this.$emit("change", data);
            this.$emit("input", data);

            this.clearError();
        },

        onRemove() {
            this.$emit("change", null);
            this.$emit("input", null);

            this.clearError();
        }
    },

    props: {
        disabled: {
            type: Boolean,
            default: false,
        },
        label: String,
        multiple: Boolean,
        options: Array,
        placeholder: String,
        searchable: Boolean,
        value: Array|String,
        allowEmpty: {
            type: Boolean,
            default: false,
        },
        valueKey: {
            type: String, default: 'value',
        },
        textKey: {
            type: String, default: 'text',
        },
    },

    mounted() {
        const dataList = this.dataOptions.filter(item => {
            const data = typeof(item) === 'object' && item[this.valueKey] !== undefined
                ? item[this.valueKey] : item;
            return data === this.value;
        });
        this.data = dataList.length > 0 ? dataList[0] : null;
    }
}

</script>
<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>