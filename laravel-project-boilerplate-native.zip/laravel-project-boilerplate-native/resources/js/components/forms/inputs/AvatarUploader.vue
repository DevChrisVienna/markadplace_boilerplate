<template>
    <div class="card card-profile shadow">
        <div class="row justify-content-center">
            <div class="col-lg-3 order-lg-2">
                <div class="card-profile-image">
                    <div :class="styleClass.imageFrame" :style="inlineFrameSize">
                        <img :src="value" :class="styleClass.avatarImage" ref="preview">
                    </div>
                </div>
            </div>
        </div>
        <div class="border-0 card-header mt--5 p-0 text-center">
            <button v-if="!loading || value == null || value == ''" type="button" @click="$refs.input.click()" class="btn btn-default rounded-circle text-center m-0" style="padding: 5px;">
                <i class="fa fa-pen p-2"></i>
            </button>
            <button v-else type="button" disabled class="btn btn-default rounded-circle text-center disabled m-0" style="padding: 5px;">
                <i class="fa fa-spinner fa-spin p-2"></i>
            </button>
            <input type="file" hidden ref="input" @change="imageUploaded" />
        </div>
        <div v-if="hasError" class="mt--3 mb-3 pl-3 pr-3 text-center">
            <span class="text-danger" v-text="errorMessage"></span>
        </div>
    </div>
</template>
<script>
export default {
    name: 'AvatarUploader',
    computed: {

        inlineFrameSize() {
            return {
                width: `${ this.frameSize.width } px`,
                height: `${ this.frameSize.height } px`,
            };
        },

        errorMessage() {
            return Array.isArray(this.error)
                ? this.error[0]
                : this.error;
        },

        hasError() {
            return this.error && (
                Array.isArray(this.error)
                    ? !this.error.length
                    : !this.error.trim().length
            );
        },

        styleClass() {
            return {
                imageFrame: {
                    'rounded-circle': this.rounded,
                    'shadow': true,
                    'avatar-frame': true,
                    'frame': true,
                },
                avatarImage: {
                    'avatar-image': true,
                    'blur': this.loading,
                }
            }
        },

    },
    data: () => ({
        loading: false,
        isRequesting: false,
        frameSize: 180,
        error: "",
    }),
    methods: {

        clearErrors() {
            this.error = ""
        },

        imageUploaded(event) {
            if (!(event.target.files && event.target.files[0])) {
                return
            }
            this.loading = true;
            let reader = new FileReader();
            reader.onload = (e) => setTimeout(() => this.onImageLoad(e), 500);
            reader.readAsDataURL(event.target.files[0]);
        },

        onImageLoad(e) {
            setTimeout(() => this.rescaleImage(), 300);
            this.$refs.preview.src = e.target.result;
            this.$emit('input', e.target.result);
            this.$emit('change', e.target.result);
        },

        resetImageScale() {
            let image = this.$refs.preview;
            image.style.minWidth = '';
            image.style.minHeight = '';
            image.style.maxWidth = '';
            image.style.maxHeight = '';
        },

        rescaleImage() {
            this.resetImageScale();
            let image = this.$refs.preview;
            let property = image.naturalWidth >= image.naturalHeight
                ? ['height', 'width', 'minHeight', 'minWidth', 'maxWidth']
                : ['width', 'height', 'minWidth', 'minHeight', 'maxHeight'];
            let length = image.naturalWidth > image.naturalHeight 
                ? [image.naturalWidth, image.naturalHeight]
                : [image.naturalHeight, image.naturalWidth];

            image.style[property[0]] = image.style[property[1]] = 'unset';
            image.style[property[2]] = image.style[property[3]] = '100%';
            image.style[property[4]] = (length[0] * (this.frameSize[property[0]] / length[1])) + 'px';
            this.loading = false;
        }
        
    },
    props: {
        value: {
            default: '/user-default.png',
            type: String|Object
        },
        size: Number,
        height: Number,
        width: Number,
        size: Number,
        rounded: {
            default: true,
            type: Boolean,
        },
    },

    watch: {
        value() {
            this.clearErrors();
        }
    },

    mounted() {
        this.frameSize = this.size || this.frameSize;
        this.frameSize = {  
            height: this.height || this.size || this.frameSize,
            width: this.width || this.size || this.frameSize,
        };
        this.loading = true;
        this.$refs.preview.onload = () => {
            setTimeout(() => this.rescaleImage(), 300);
        };
    }
}
</script>