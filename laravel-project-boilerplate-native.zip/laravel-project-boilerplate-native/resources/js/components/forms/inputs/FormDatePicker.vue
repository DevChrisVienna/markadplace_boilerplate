<template>
    <div :class="styleClass.formGroup">
        <label v-if="label" class="form-control-label">{{label}}</label>
        <div :class="styleClass.inputGroup">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="ni ni-calendar-grid-58"></i></span>
            </div>
            <input
                :class="styleClass.input"
                :id="id"
                :label="label"
                :name="name"
                :placeholder="placeholder"
				readonly=""
                ref="datepicker" 
                type="text"
                :value="value"
				
                @changed="changed"
            />
        </div>
        <span v-if="hasError" class="text-danger" >{{errorMessage}}</span>
    </div>
</template>
<script>
import { mixins } from 'utils'
import daterangepicker from 'daterangepicker';
import 'daterangepicker/daterangepicker.css';

export default {
	name:'FormDatePicker',
	props: {
		label: String,
		name: String,
		placeholder: String,
		requiredText: String,
		value: String,
		format: String,
		alternative: Boolean,
		time: Boolean,
		isRange: Boolean,
		startDate: String,
		endDate: String,
	},
	computed: {

        errorMessage() {
            return Array.isArray(this.error)
                ? this.error[0]
                : this.error;
		},

		id() {
			return `datepicker_${this._uid}`;
		},

        hasError() {
            return this.error
                && (!this.isArrayAnEmptyString()
                || this.isArrayAnEmptyArray());
		},
		
		defaultFormat() {
			return this.time
				? 'YYYY-MM-DD hh:mm A'
				: 'YYYY-MM-DD';
		},

		usedFormat() {
			return this.format || this.defaultFormat
		},

		initialStart() {
			return this.isRange
				? moment(this.startDate).format(this.usedFormat)
				: this.initialValue;
		},

		initialEnd() {
			return this.isRange
				? moment(this.endDate).format(this.usedFormat)
				: null;
		},

		styleClass() {
			return {
				formGroup: {
					'form-group': true,
					'datepicker': true,
                    'has-danger': this.hasError,
				},
				inputGroup: {
                    'is-invalid': this.hasError,
					'input-group': true,
					'input-group-alternative': this.alternative,
				},
				input: {
					'form-date-picker-field': true,
                    'form-control': true,
                    'is-invalid': this.hasError,
				}
			}
		}
	},
	data() {
		return {
			data: this.value,
			initialValue: null,
			error: null,
		}
	},
	methods: {
		changed(event) {
			this.$nextTick(() => {
				this.clearError()
				this.$emit("input", this.data = event.target.value)
			});
		},

        clearError() {
            this.error = null;
        },
        
        isArrayAnEmptyString() {
            return typeof this.error === "string"
                && !this.error.trim().length;
        },
        
        isArrayAnEmptyArray() {
            return Array.isArray(this.error)
                && !this.error.length;
        },

		setDatePicker() {
			let options = {
				singleDatePicker: !this.isRange,
				showDropdowns: true,
                timePicker: this.time,
				format: this.usedFormat,
                startDate: this.initialStart,
                endDate: this.initialEnd,
                locale: { format: this.usedFormat }
			}
			let datepicker = $(`#${ this.id }`)
				.daterangepicker(options)
				.on('hide', event => {
					event.preventDefault();
					event.stopPropagation();
				})
				.on('apply.daterangepicker', (ev, picker) => {
					this.data = this.isRange 
						? {
							start: picker.startDate.format(this.usedFormat),
							end: picker.endDate.format(this.usedFormat),
						}
						: picker.startDate.format(this.usedFormat);
					this.clearError();
					this.$emit("input", this.data);
					this.$emit("change", this.data);
				});
		}
	},
	watch: {
		isRange() {
			this.setDatePicker()
		},
		time() {
			this.setDatePicker()
		},
	},

	mounted() {
		this.initialValue = this.value == null
			? moment().format(this.usedFormat)
			: moment(this.value).format(this.usedFormat);
		console.log(this.initialValue)
		this.setDatePicker()
	},
}
</script>