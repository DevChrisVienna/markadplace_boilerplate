<template>
    <div :class="styleClass.formGroup">
        <label v-if="label"
            :for="id"
            class="form-control-label"
            v-text="label"></label>
        <label v-if="!disabled && optionalLabel"
            :for="id"
            class="form-control-label text-muted"
            v-text="optionalLabel"></label>
        <div v-if="hasIcon" class="input-group-prepend">
            <div class="input-group-text">
                <i class="fa fa-user"></i>
            </div>
        </div>
        <template v-if="mask">
            <input v-if="type != 'textarea'"
                :type="type"
                :name="name"
                :class="styleClass.input"
                :readonly="disabled"
                :value.sync="value"
                :placeholder="placeholder"
                autocomplete="off"
                ref="input"
                @input="input"
                @blur="blur"
                @focus="focus"
                v-mask="mask" />
            <textarea v-else
                :type="type"
                :name="name"
                :class="styleClass.input"
                :readonly="disabled"
                :value.sync="value"
                :placeholder="placeholder"
                autocomplete="off"
                ref="input"
                @input="input"
                @blur="blur"
                @focus="focus"
                v-mask="mask"
                :rows="rows"></textarea>
        </template>
        <template v-else>
            <input v-if="type != 'textarea'"
                :type="type"
                :name="name"
                :class="styleClass.input"
                :readonly="disabled"
                :value.sync="value"
                :placeholder="placeholder"
                autocomplete="off"
                ref="input"
                @input="input"
                @blur="blur"
                @focus="focus" />
            <textarea v-else
                :type="type"
                :name="name"
                :class="styleClass.input"
                :readonly="disabled"
                :value.sync="value"
                :placeholder="placeholder"
                autocomplete="off"
                ref="input"
                @input="input"
                @blur="blur"
                @focus="focus"
                :rows="rows"></textarea>
        </template>
        <span v-if="hasError" class="text-danger" v-text="errorMessage"></span>
    </div>
</template>
<script>
import { mask } from 'vue-the-mask';

export default {
    name: "FormInput",
    directives: { mask },
    props: {
        capitalize: {
            type: Boolean,
            default: false,
        },
        disabled: {
            type: Boolean,
            default: false,
        },
        required: {
            default: false,
            type: Boolean,
        },
        label: String,
        optionalLabel: String,
        name: String,
        placeholder: String,
        type: {
            default: 'text',
            type: String,
        },
        value: String | Number | Object | Array,
        alternative: {
            type: Boolean,
            default: false,
        },
        icon: String,
        mask: String|Array,
        rows: {
            default: 5,
            type: Number,
        },
    },
    computed: {
        errorMessage() {
            return Array.isArray(this.error)
                ? this.error[0]
                : this.error;
        },

        hasError() {
            return this.error
                && (!this.isArrayAnEmptyString()
                || this.isArrayAnEmptyArray());
        },

        hasIcon() {
            return this.icon && this.icon.trim().length
        },
        
        styleClass() {
            return {
                formGroup: {
                    'form-group': true,
                    'input-group': this.hasIcon,
                    'has-danger': this.hasError,
                    'form-group-disabled': this.disabled,
                },
                input: {
                    'form-control': true,
                    'form-control-alternative': this.alternative,
                    'is-invalid': this.hasError,
                    'text-capitalize': this.capitalize,
                },
            }
        },
    },
    data() {
        return {
            data: this.value,
            error: "",
        }
    },
    methods: {

        clearError() {
            this.error = null;
        },

        input(event) {
            if (this.hasError) {
                this.clearError();
            }
            this.$emit("input", this.data = event.target.value);
        },

        blur(event) {
            this.$emit("blur", event)
        },

        focus(event) {
            this.$emit("focus", event)
        },
        
        isArrayAnEmptyString() {
            return typeof this.error === "string"
                && !this.error.trim().length;
        },
        
        isArrayAnEmptyArray() {
            return Array.isArray(this.error)
                && !this.error.length;
        },

    }
}
</script>