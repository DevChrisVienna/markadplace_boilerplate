<template>
    <span :class="styleClass.frameWrapper">
        <div :class="styleClass.avatarFrame" ref="frame">
            <img :src="src" :class="styleClass.avatarImage" ref="preview">
        </div>
    </span>
</template>
<script>
export default {
    name: 'AvatarBadge',
    computed: {
        styleClass() {
            return {
                frameWrapper: {
                    'rounded-circle': this.rounded,
                    'avatar-sm': true,
                },
                avatarFrame: {
                    'rounded-circle': this.rounded,
                    'shadow': this.raised,
                    'avatar-frame': true,
                },
                avatarImage: {
                    'avatar-image': true,
                    'blur': this.loading,
                },
            }
        },
    },
    data: () => ({
        loading: false,
        frameSize: 36,
    }),
    methods: {

        resetImageScale() {
            let image = this.$refs.preview;
            image.style.minWidth = '';
            image.style.minHeight = '';
            image.style.maxWidth = '';
            image.style.maxHeight = '';

            this.$refs.frame.style.width = this.frameSize + 'px';
            this.$refs.frame.style.height = this.frameSize + 'px';
        },

        rescaleImage() {
            this.resetImageScale();
            let image = this.$refs.preview;
            let property = image.naturalWidth > image.naturalHeight
                ? ['height', 'width', 'minWidth', 'maxHeight']
                : ['width', 'height', 'minHeight', 'maxWidth'];
            let length = image.naturalWidth > image.naturalHeight 
                ? [image.naturalWidth, image.naturalHeight]
                : [image.naturalHeight, image.naturalWidth];

            image.style[property[0]] = this.frameSize + 'px';
            image.style[property[1]] = 'unset';
            image.style[property[2]] = image.style[property[3]] = (length[0] * (this.frameSize / length[1])) + 'px';
            this.loading = false;
        }
        
    },
    props: {
        size: Number,
        rounded: {
            default: true,
            type: Boolean,
        },
        src: {
            default: '/user-default.png',
            type: String|Object
        },

        raised: {
            type: Boolean,
            default: false,
        }
    },

    mounted() {
        this.frameSize = this.size > 0
            ? this.size
            : this.frameSize;
        this.resetImageScale()
        this.loading = true;
        this.$refs.preview.onload = () => {
            setTimeout(() => this.rescaleImage(), 300);
        };
    }
    
}
</script>