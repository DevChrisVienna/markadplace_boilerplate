<template>
    <div :class="fabContainerClass" v-cloak>
        <ul ref="action_buttons" class="list-unstyled">
            <li v-if="hasMultiple">
                <a href="#" class="hide-on-hover">
                    <i class="fas fa-bars"></i>
                </a>
            </li>
            <slot></slot>
        </ul>
    </div>
</template>
<script>
export default {
    name: 'Fab',
    computed: {
        hasMultiple() {
            return this.expandedSize > 1
        },
        fabContainerClass() {
            return `__floating-action-button floating-button-${ this.expandedSize } animated animatedFadeInUp fadeInUp`;
        },
    },
    props: {
        expandedSize: {
            type: Number,
            default: 1,
        }
    }
}
</script>