<template>
    <li>
        <a :href="href"
            @click.stop="click" 
            data-toggle="tooltip"
            ref="anchor"
            :title="label">
            <i :class="icon"></i>
        </a>
    </li>
</template>
<script>
import { bus }  from 'src/utils/bus';

export default {
    name: 'ActionButton',
    computed: {
        isLink() {
            return this.href != '#';
        },
    },
    methods: {
        click(event) {
            this.isLink
                ? window.location = this.href
                : bus.$emit(this.emit);
        },
        initializeTooltip() {
            $(this.$refs.anchor).tooltip({
                tooltipClass: "tooltip-badge",
                boundary: "window",
                title: this.label,
                content: this.label,
                placement:'left',
            });
        }
    },
    props: {
        icon: String,
        label: String,
        href: {
            type: String,
            default: '#',
        },
        emit: String,
    },

    mounted() {
        if (this.label) {
            this.initializeTooltip();
        }
    }
}
</script>
