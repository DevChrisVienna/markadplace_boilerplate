<template>
    <form :class="styleClass.form" @submit.prevent="search">
        <div class="form-group search-form-group mb-0">
            <div class="input-group input-group-alternative">
                <div class="input-group-prepend">
                    <span class="input-group-text">
                        <i class="fa fa-search"></i>
                    </span>
                </div>
                <input :class="styleClass.formControl" v-model="form.field" placeholder="Search" type="text" @input="clear" @blur="clear">
            </div>
            <div v-if="hasResults" class="bg-white pt-3 pb-3 search-result">
                <div v-if="result.length == 0" class="empty-placeholder">
                    No results found
                </div>
                <div v-for="(item, key) in result" :key="key" >
                    <a :href="item.display_route">
                        <div class="display-text text-muted" v-text="item.display_name"></div>
                        <div class="sub-text text-muted" v-text="item.display_sub_name"></div>
                    </a>
                </div>
            </div>
        </div>
    </form>
</template>
<script>
import mixins from 'utils/mixins'
import Form from 'models/components/Form'

export default {
    name: 'SearchField',

    computed: {
        styleClass() {
            return {
                form: this.navbar
                    ? 'navbar-search navbar-search-dark form-inline mr-3 d-none d-md-flex ml-lg-auto'
                    : 'mt-4 mb-3 d-md-none',
                formControl: {
                    'form-control': true,
                    'text-white': this.dark,
                },
            }
        },
    },

    data: () => ({
        hasResults: false,
        form: new Form({
            field: '',
        }),
        result: [],
    }),

    methods: {
        clear() {
            setTimeout(() => this.hasResults = false, 200);
        },

        search() {
            this.form.sendPost(this.route)
                .then(response => {
                    this.result = response.data.result.result;
                })
                .catch(error => {
                    this.promptErrors(error.response.message);
                })
                .finally(() => this.hasResults = true);
        }
    },

    mixins: [ mixins ],

    props: {
        route: {
            required: true,
            type: String,
        },
        dark: {
            type: Boolean,
            default: true,
        },
        navbar: {
            type: Boolean,
            default: true,
        }
    }
}
</script>