<template>
    <div :id="id.container" class="input-slider-container">
        <div :id="id.component" ref="slider" class="input-slider" :data-range-value-min="min" :data-range-value-max="max"></div>
        <div class="row mt-3 d-none">
            <div class="col-6">
                <span :id="id.value" class="range-slider-value" :data-range-value-low="min"></span>
            </div>
        </div>
    </div>
</template>
<script>

export default {
    name: "Slider",
    computed: {
        id() {
            return {
                container: 'input-slider-' + this._uid + '-container',
                component: 'input-slider-' + this._uid,
                value: 'input-slider-' + this._uid + '-value',
            }
        },
    },

    data() {
        return { 
            sliderValue: this.value,
        };
    },

    methods: {
        initialize() {
            noUiSlider.create(this.$refs.slider, {
                start: this.sliderValue || 0,
                step: 5,
                connect: 'lower',
                tooltips: [true],
                range: {
                    'min': this.min,
                    'max': this.max
                }
            });
            this.$refs.slider.noUiSlider.on('change', (values) => this.onChange(values));
            if (this.disabled) {
                this.$refs.slider.setAttribute('disabled', true);
            }
        },

        onChange(values) {
            this.$emit('input', this.sliderValue = parseInt(values[0]));
        },
    },
    watch: {
        value(newVal, oldVal) {
            if (oldVal === undefined) {
                this.$refs.slider.noUiSlider.set(newVal)
            } else if (newVal !== this.sliderValue) {
                this.$refs.slider.noUiSlider.set(this.sliderValue = newVal);
            }
        },
        disabled(newValue) {
            newValue
                ? this.$refs.slider.setAttribute('disabled', true)
                : this.$refs.slider.removeAttribute('disabled');
        }
    },
    props: {
        min: 0,
        max: 100,
        value: Number,
        disabled: false,
    },

    mounted() {
        this.initialize();
    }
}
</script>
