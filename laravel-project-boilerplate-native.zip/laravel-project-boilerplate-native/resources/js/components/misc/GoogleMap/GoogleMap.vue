<template>
    <div>
        <div class="form-group mb-2">
            <autocomplete
                class="form-control"
                @place_changed="setPlace">
            </autocomplete>
        </div>
        <gmap-map
            :center="center"
            :zoom="12"
            style="width:100%; height: 400px;"
            @click="selectMarker"
        >
            <gmap-marker
                :key="index"
                v-for="(m, index) in markers"
                :position="m.position"
                @click="selectMarker"
            ></gmap-marker>
        </gmap-map>
    </div>
</template>

<script>
import { default as Autocomplete } from './Autocomplete';


export default {
    name: "GoogleMap",
    components: { Autocomplete },
    data() {
        return {
            // default to Montreal to keep it simple
            // change this to whatever makes sense
            center: { lat: 45.508, lng: -73.587 },
            markers: [],
            places: [],
            currentPlace: null,
            geocoder: null,
            addressStructure: {
                lat: 0,
                lng: 0,
                barangay: '',
                city: '',
                province: '',
                country: '',
                zipcode: ''
            },
            addressAllocation: {
                barangay: 'neighborhood',
                city: 'locality',
                province: 'administrative_area_level_2',
                country: 'country',
                zipcode: 'postal_code'
            }
        };
    },

    mounted() {
        this.center = {
            lat:  parseFloat(this.initialLocation.lat || 0),
            lng: parseFloat(this.initialLocation.lng || 0)
        };
        // this.geolocate();
        if (this.initialValue) {
            this.markers = this.multiple ? this.initialValue : [this.initialValue];
        }
    },

    methods: {
        getGeocoder() {
            return this.geocoder || (this.geocoder = new google.maps.Geocoder());
        },

        loadAddress(lat, lng) {
            lat = lat || 0;
            lng = lng || 0;
            return new Promise((resolve, reject) => {
                this.getGeocoder().geocode({ location: { lat, lng } }, (result, status) => {
                    if (status != "OK") {
                        reject(result, status);
                    } else {
                        let addresses = this.filterAddresses(result);
                        let address = this.transformData(addresses[0]);
                        resolve(address);
                    }
                });
            })
        },

        transformData(geocodedAddress) {
            let address = {
                ... this.addressStructure,
                lat: geocodedAddress.geometry.location.lat(),
                lng: geocodedAddress.geometry.location.lng(),
            };
            geocodedAddress.address_components.forEach(component => {
                for (const key in this.addressAllocation) {
                    if (component.types.includes(this.addressAllocation[key])) {
                        address[key] = component.long_name;
                        break;
                    }    
                }
            });

            return address;
        },

        filterAddresses(addresses) {
            let filteredAddresses = addresses.filter(address => !address.formatted_address
                .toLowerCase().includes("unnamed"));

            return filteredAddresses.length > 0
                ? filteredAddresses
                : addresses;
        },

        selectMarker(payload) {
            this.saveMarker(
                payload.latLng.lat(),
                payload.latLng.lng()
            );
        },

        saveMarker(lat, lng) {
            if (this.disabled) {
                return;
            }
            this.loadAddress(lat, lng)
            .then(response => {
                const data = {
                    address: response,
                    position: { lat, lng }
                };
                this.multiple
                    ? this.markers.push(data)
                    : this.markers = [data];
                this.$emit('input', this.markers);
                this.$emit('change', this.markers);
            })
            .catch((error, status) => {
                console.log(error, status)
            });
        },

        // receives a place object via the autocomplete component
        setPlace(place) {
            this.currentPlace = place;
            this.addMarker();
        },
        addMarker() {
            if (!this.currentPlace) {
                return;
            }
            const marker = {
                lat: this.currentPlace.geometry.location.lat(),
                lng: this.currentPlace.geometry.location.lng()
            };
            this.saveMarker(marker.lat, marker.lng);
            this.places.push(this.currentPlace);
            this.center = marker;
            this.currentPlace = null;
        },
        geolocate() {
            navigator.geolocation.getCurrentPosition(position => {
                this.center = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };
            });
        }
    },

    props: {
        multiple: {
            default: false,
            type: Boolean,
        },
        disabled: {
            type: Boolean,
            default: false,
        },
        initialLocation: {
            type: Object,
            default: () => ({
                lat: window.google_maps_default_lat || 14.5995124,
                lng: window.google_maps_default_lng || 120.9842195
            }),
        },
        initialValue: Object | Array
    }

};
</script>