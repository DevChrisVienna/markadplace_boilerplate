
<template>
    <input
        ref="input"
        v-bind="$attrs"
        v-on="$listeners"
        class="form-control"
        />
</template>

<script>
export default (function (x) { return x.default || x })(
    require('vue2-google-maps/dist/components/autocompleteImpl.js')
)
</script>
