<template>
    <ul class="pagination">
        <li v-if="!simplified" class="page-item">
            <a
                :class= "[ 
                    'p-2 page-link', 
                    firstClasses,
                    isInFirstPage ? 'disabled' : '',
                ]"
                @click="onClickFirstPage"
            >
                <i class="fas fa-fast-backward"></i>
            </a>
        </li>
        <!-- <li class="mr-2 page-item">
            <a
                :class= "[ 
                    'p-2 page-link', 
                    previousClasses,
                    isInFirstPage ? 'disabled' : '',
                ]"
                @click="onClickPreviousPage"
            >
                <i class="fas fa-step-backward"></i>
            </a>
        </li> -->
        <li v-for="(page, key) in pages" :key=key :class="'page-item ' + (isPageActive(page.name) ? ' disabled '+ activeItemClass : '')">
            <a
                :class= "[ 
                    'p-2 page-link', 
                    pageClasses,
                ]"
                @click="onClickPage(page.name)"
            >
                {{ page.name }}
            </a>
        </li>
        <!-- <li class="ml-2 page-item">
            <a
                :class= "[ 
                    'p-2 page-link', 
                    nextClasses,
                    isInLastPage ? 'disabled' : '',
                ]"
                @click="onClickNextPage"
            >
                <i class="fas fa-step-forward"></i>
            </a>
        </li> -->

        <li v-if="!simplified" class="page-item">
            <a
                :class= "[ 
                    'p-2 page-link', 
                    lastClasses,
                    isInLastPage ? 'disabled' : '',
                ]"
                @click="onClickLastPage"
            >
                <i class="fas fa-fast-forward"></i>
            </a>
        </li>
    </ul>
</template>

<script>
export default {
	name: "Pagination",
	props: {
        maxVisibleButtons: { type: Number, default: 5 },
        totalPages: { type: Number, required: true, default: 1 },
        total: { type: Number, required: true, default: 0 },
        currentPage: { type: Number, required: true, default: 1 },
        activeItemClass: { type: String, default: "active" },
        pageClasses: { type: String, default: "" },
        firstClasses: { type: String, default: "" },
        previousClasses: { type: String, default: "" },
        nextClasses: { type: String, default: "" },
        lastClasses: { type: String, default: "" },
        firstText: { type: String, default: "<<" },
        previousText: { type: String, default: "<" },
        nextText: { type: String, default: ">" },
        lastText: { type: String, default: ">>" },
        simplified: { type: Boolean, default: false },
    },
	computed: {
        startPage() {
            if (this.totalPages < this.maxVisibleButtons) {
                return 1;
            }
            if(this.currentPage > Math.floor(this.maxVisibleButtons / 2)){
               if((this.totalPages - Math.floor(this.maxVisibleButtons / 2)) < this.currentPage){
                  return this.totalPages - this.maxVisibleButtons + 1;
               }
               return this.currentPage - Math.floor(this.maxVisibleButtons / 2);
            }
            else{
               return 1;
            }
        },
        pages() {
            const range = [];
            for (let i = this.startPage;
                i <= Math.min(this.startPage + this.maxVisibleButtons - 1, this.totalPages);
                i+= 1 ) {
                range.push({
                name: i,
                isDisabled: i === this.currentPage
                });
            }

            return range;
        },
        isInFirstPage() {
            return this.currentPage === 1;
        },
        isInLastPage() {
            return this.currentPage === this.totalPages;
        },
	},
	methods: {
        onClickFirstPage() {
            this.$emit('pageChanged', 1);
        },
        onClickPreviousPage() {
            this.$emit('pageChanged', this.currentPage - 1);
        },
        onClickPage(page) {
            this.$emit('pageChanged', page);
        },
        onClickNextPage() {
            this.$emit('pageChanged', this.currentPage + 1);
        },
        onClickLastPage() {
            this.$emit('pageChanged', this.totalPages);
        },
        isPageActive(page) {
            return this.currentPage === page;
        },
    },
};
</script>
