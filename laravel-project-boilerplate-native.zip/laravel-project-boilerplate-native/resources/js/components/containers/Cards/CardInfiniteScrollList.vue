<template>
    <div id="list-conatiner" v-if="simple" :class="styleClass.scrollTable" :style="inlineStyle" ref="list">
        <table class="table-responsive">
            <tr v-if="!fetching && recordsEmpty">
                <td :colspan="headerCount">
                    No record was found
                </td>
            </tr>
            <tr v-else v-for="(record, key) in this.records" :key="key">
                <slot name="body" :record="record" :refresh-page="refreshTable"></slot>
            </tr>
            <tr v-if="fetching">
                <td :colspan="headerCount">
                    <slot name="loading">
                        <i class="fa fa-spinner fa-spin pr-1"></i>
                        Loading data, please wait ...
                    </slot>
                </td>
            </tr>
        </table>
    </div>
    <card-table v-else :title="title" ref="table" :class="styleClass.scrollTable" :styleClass="inlineStyle">
        <template slot="title-buttons">
            <slot name="title-buttons"></slot>
            <button
                ref="refreshButton"
                class="btn btn-sm btn-link btn-tooltip" 
                data-toggle="tooltip"
                title="Refresh"
                data-original-title="Refresh"
                @click="refreshTable">
                <i class="fa fa-refresh"></i>
            </button>
        </template>
        <template slot="thead">
            <slot name="header"></slot>
        </template>
        <template slot="tbody">
            <tr v-if="!fetching && recordsEmpty">
                <td :colspan="headerCount">
                    No record was found
                </td>
            </tr>
            <tr v-else v-for="(record, key) in this.records" :key="key">
                <slot name="body" :record="record" :refresh-page="refreshTable"></slot>
            </tr>
            <tr v-if="fetching">
                <td :colspan="headerCount">
                    <i class="fa fa-spinner fa-spin pr-1"></i>
                    Loading data, please wait ...
                </td>
            </tr>
        </template>
        <template slot="footer">
            <slot name="footer"></slot>
        </template>
    </card-table>
</template>
<script>
import mixins from 'utils/mixins';
const CardTable = () => import('./CardTable.vue');


export default {
    name: 'CardInfiniteScrollList',
    components: { CardTable },

    
    computed: {
        inlineStyle() {
            return (this.maxHeight ?  'max-height:' + this.maxHeight + '; ' : '')
        },

        headerCount() {
            return this.$slots.header ? this.$slots.header.length : 1;
        },

        recordsEmpty() {
            return this.records && this.records.length == 0;
        },

        hasMore() {
            return !!(this.pagination.next_page_url || this.pagination.next);
        },

        styleClass() {
            return {
                scrollTable: {
                    'infinite-scroll-table': true,
                    'long': this.long,
                }
            };
        },

    },

    props: {
        title: String,
        fetchLink: String,
        promptFail: {
            default: true,
            type: Boolean,
        },
        paginatePath: {
            type: String,
            default: "",
        },
        long: Boolean,
        simple: {
            default: false,
            type: Boolean,
        },
        maxHeight: String,
    },

    data: () => ({
        link: '',
        fetching: true,
        pagination: { next_page_url: true },
        records: [],
    }),

    methods: {

        fetchData() {
            this.fetching = true;
            axios(this.link)
                .then(response => this.mapData(response))
                .catch(error => this.fetchFailed(error))
                .finally(() => this.fetching = false);
        },

        fetchFailed(error) {
            this.$emit('fetch-failed', error);
            if (this.promptFail) {
                this.promptErrors('Failed to load table data');
            }
            this.pagination = { data: [] };
        },

        mapData(response) {
            this.pagination =this.getPaginationFromPath(response);
            this.link = this.pagination.next_page_url || this.pagination.next;
            this.pagination.data.forEach(item => this.records.push(item));
            this.$emit('recordloaded', this.records);
        },

        getPaginationFromPath(data) {
            this.paginatePath.split('.')
                .forEach(index => data = data[index]);
            return data;
        },
        
        isNearToBottom(table) {
            return table.scrollTop + table.clientHeight > table.scrollHeight - 100;
        },
        
        loadNewData(event) {
            let table = event.target;
            if (this.fetching || !this.hasMore || !this.isNearToBottom(table))  {
                return;
            }
            this.fetchData();
        },

        movePage(event) {
            event.preventDefault();
            this.link = event.target.href
            this.currentPage = parseInt(event.target.dataset.page)
            this.fetchData();
        },

        refreshTable() {
            this.link = this.fetchLink;
            this.records = [];
            this.fetchData();
        }

    },

    mixins: [ mixins ],

    mounted() {
        setTimeout(() => {
            (this.simple ? this.$refs.list : this.$refs.table.$el.querySelector('.table-responsive'))
                .onscroll = e => this.loadNewData(e);
            this.refreshTable();
            $(this.refreshButton).tooltip();
        }, 1000)
    },
}
</script>
