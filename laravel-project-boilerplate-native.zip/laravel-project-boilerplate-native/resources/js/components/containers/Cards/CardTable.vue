<template>
    <div class="card shadow">
        <div class="card-header border-0">
            <div class="row align-items-center">
                <div class="col-sm-12 col-md-4">
                    <h3 class="mb-0" v-text="title" ></h3>
                </div>
                <div class="col-sm-12 col-md-8 text-right">
                    <slot name="title-buttons"></slot>
                </div>
            </div>
            </div>
            <div class="table-responsive">
                <table class="table align-items-center table-flush">
                    <thead class="thead-light">
                        <slot name="thead"></slot>
                    </thead>
                    <tbody>
                        <slot name="tbody"></slot>
                    </tbody>
                </table>
            </div>
            <div class="card-footer py-4">
                <slot name="footer"></slot>
            </div>
          </div>
</template>
<script>
export default {
    name: 'CardTable',
    computed: {
        hasFooter() {
            return !!this.$slots.footer
        },
    },
    props: {
        title: String,
    },
}
</script>