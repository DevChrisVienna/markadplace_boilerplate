<template>
    <th>
        <slot></slot>
        >
    </th>
</template>

<script>
export default {
    name: "DataTableHeader",

    data: () => ({}),

    methods: {}
    
}
</script>