// export { default as Modal } from './Modal'
export const Modal = () => import('./Modal');