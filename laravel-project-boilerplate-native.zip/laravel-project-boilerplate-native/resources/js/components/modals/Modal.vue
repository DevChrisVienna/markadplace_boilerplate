<template>
    <div :id="id" tabindex="-1" aria-labelledby="modal-form" :class="styleClass.modal">
        <div :class="styleClass.modalDialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 v-if="title" v-text="title"></h3>
                    <slot v-else name="header"></slot>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body pt-0 pb-0">
                    <slot></slot>
                </div>
                <div class="modal-footer">
                    <slot name="footer"></slot>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    name: "Modal",
    computed: {

        id() {
            return `modal-component-${ this._uid }`
        },
        
        selector() {
            return `#${ this.id }`
        },

        styleClass() {
            return {
                modal: {
                    'modal': true,
                    'fade': true,
                    // 'modal-lg': !this.small,
                },
                modalDialog: {
                    'modal-dialog': true,
                    'modal-dialog-centered': true,
                    'modal-lg': !this.small,
                }
            }
        }

    },

    data() {
        return {
            fullscreen: false,
            icon: false,
            show: this.value,
        }
    },

    methods: {

        initializeModal() {
            $(this.selector).on('show.bs.modal', e => {
                // this.$nextTick(() => this.$emit("input", this.show = true))
            })
            $(this.selector).on('hide.bs.modal', e => {
                this.$emit('hidden');
                if (!e.target.classList.contains('modal')) {
                    e.preventDefault();                    
                    return
                }
                
                // this.$nextTick(() => this.$emit("input", this.show = false))
                // this.$nextTick(() => this.show = false)
            })
            $(this.selector).modal('hide');
        },

        toggleVisibility() {
            $(this.selector).modal(this.show ? 'show' : 'hide');
        }
    },

    props: {
        value: {
            type: Boolean,
            default: false,
        },
        subtitle: String,
        title: String,
        small: {
            type: Boolean,
            default: true,
        },
    },

    watch: {
        show() {
            this.toggleVisibility();
        },

        value(newValue) {
            this.show = newValue
        },
    },

    mounted() {
        this.initializeModal();
    },
}
</script>