<script>
import { bus } from 'utils/bus';
import mixins from 'utils/mixins';
// import * as pages from 'pages';

// const components = Object.assign({}, pages);

export default {
    name: 'App',
    // components,

    methods: {
        initializeBroadcast() {
            //
        }
    },

    mixins: [mixins],

    props: {
        userId: Number,
    },

    mounted() {
        if (this.userId && window.Echo) {
            this.initializeBroadcast();
        }
    }
}
</script>