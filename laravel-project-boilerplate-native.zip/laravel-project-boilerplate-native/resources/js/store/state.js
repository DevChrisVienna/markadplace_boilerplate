
export const state = {
    page: {}
}