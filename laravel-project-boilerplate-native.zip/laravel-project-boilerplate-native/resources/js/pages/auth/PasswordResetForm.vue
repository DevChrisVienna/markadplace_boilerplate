<script>
import mixins from 'utils/mixins';
import Form from 'models/components/Form';

export default {
    name: 'PasswordResetForm',

    data: () => ({
        form: new Form({
            token: '',
            password: '',
            password_confirmation: '',
        }),
    }),

    methods: {

        clearPassword() {
            return this.form.password = this.form.password_confirmation = '';
        },

        signIn(event) {
            event.preventDefault();

            this.form.sendPost(route('api.backend.auth.password-reset'))
                .then(response => this.signInSucceeded(response))
                .catch(error => this.signInFailed(error))
        },
        signInSucceeded(response) {
            this.promptSuccess(response.data.message);
            this.redirect('pages.login', {}, 3000);
        },
        signInFailed(error) {
            this.promptFormErrors(this.$refs, error);
            this.clearPassword();
        }
    },

    props: {
        token: String,
    },

    mixins: [ mixins ],

    mounted() {
        this.form.token = this.token;
    },
}
</script>