<script>
import mixins from 'utils/mixins';
import Form from 'models/components/Form';

export default {
    name: 'ForgotPasswordForm',
    data: () => ({
        form: new Form({
            email: '',
        }),
    }),

    methods: {

        submit(event) {
            event.preventDefault();

            this.form.sendPut(route('api.backend.auth.forgot-password'))
                .then(response => this.requestSucceeded(response))
                .catch(error => this.requestFailed(error))
        },
        requestSucceeded(response) {
            this.promptSuccess(response.data.message);
            this.redirect('pages.login', {}, 3000);
        },
        requestFailed(error) {
            this.promptFormErrors(this.$refs, error);
        }
    },
    mixins: [ mixins ],
}
</script>