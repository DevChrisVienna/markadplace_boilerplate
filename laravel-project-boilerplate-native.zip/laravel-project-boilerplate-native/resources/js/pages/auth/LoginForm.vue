<script>
import mixins from 'utils/mixins';
import Form from 'models/components/Form';

export default {
    name: 'LoginForm',

    data: () => ({
        form: new Form({
            email: '',
            password: '',
            remember: false,
        }),
    }),

    methods: {

        clearPassword() {
            return this.form.password = '';
        },

        signIn(event) {
            event.preventDefault();

            this.form.sendPost(route('pages.signin'))
                .then(response => this.signInSucceeded(response))
                .catch(error => this.signInFailed(error))
        },
        signInSucceeded(response) {
            location.reload();
        },
        signInFailed(error) {
            this.promptFormErrors(this.$refs, error);
            this.clearPassword();
        }
    },

    mixins: [ mixins ],
}
</script>