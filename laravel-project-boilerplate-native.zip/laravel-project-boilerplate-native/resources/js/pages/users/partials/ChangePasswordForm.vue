<template>
    <div>
        <button @click="() => showModal = true" class="btn btn-warning btn-block btn-rounded mt-3 mb-3">
            <i class="fa fa-key mr-1"></i> Change password
        </button>
        <modal v-model="showModal" title="Change Password" @hidden="onHide">
            <form @submit.prevent="" class="row">
                <div class="col-lg-12">
                    <form-input
                        v-if="isCurrentUser"
                        placeholder="Current password"
                        label="Current password"
                        v-model="form.current_password"
                        type="password"
                        ref="current_password"
                    ></form-input>
                </div>
                <div class="col-lg-12">
                    <form-input
                        placeholder="New password"
                        label="New password"
                        v-model="form.password"
                        type="password"
                        ref="password"
                    ></form-input>
                </div>
                <div class="col-lg-12">
                    <form-input
                        placeholder="Confirm password"
                        label="Confirm password"
                        v-model="form.password_confirmation"
                        type="password"
                        ref="password_confirmation"
                    ></form-input>
                </div>
                <div class="col-lg-12">
                    <button v-if="!form.isRequesting" @click="save" type="submit" class="btn btn-warning btn-rounded long float-right">
                        <i class="fa fa-save mr-1"></i> Save
                    </button>
                    <button v-else disabled class="disabled btn btn-warning btn-rounded long float-right">
                        <i class="fa fa-spinner fa-spin mr-2"></i> Please wait
                    </button>
                </div>
            </form>
        </modal>
    </div>
</template>
<script>
import mixins from 'utils/mixins';
import Form from 'models/components/Form';

export default {
    name: 'ChangePasswordForm',

    data: () => ({
        showModal: false,
        clearModal: true,
        form: new Form({
            id: 0,
            current_password: "",
            password: "",
            password_confirmation: "",
        })
    }),
    methods: {
        clearFields(includeErrors = true) {
            this.form.current_password = "";
            this.form.password = "";
            this.form.password_confirmation = "";
            if (includeErrors) {
                this.$refs.current_password ? this.$refs.current_password.clearError() : "";
                this.$refs.password.clearError();
                this.$refs.password_confirmation.clearError();
            }
        },

        onHide() {
            this.showModal = false;
            if (this.clearModal) {
                this.clearFields();
            }
        },

        async save() {
            this.clearModal = this.showModal = false;
            if (!(await this.confirm("Are you sure you want to edit this data?", "")).value) {
                this.showModal = true;
                return;
            }
            this.clearModal = this.showModal = true;
            this.form.sendPatch(route('api.backend.users.update-password', this.userId))
                .then(response => this.saved(response))
                .catch(error => this.saveFailed(error));
        },

        saved(response) {
            this.promptSuccess(response.data.message);
            this.reload(3000);
            this.onHide();
        },

        saveFailed(error) {
            this.clearFields(false);
            this.promptFormErrors(this.$refs, error);
        },
    },

    props: {
        userId: Number,
        isCurrentUser: Boolean,
    },

    mixins: [ mixins ],

    mounted() {
        this.form.id = this.userId;
    }
}
</script>