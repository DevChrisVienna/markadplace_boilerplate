<template>
    <form>
        <template v-if="!isCurrentUser">
            <div v-if="!editable" @click="toggleEdit" class="btn btn-link btn-sm text-primary float-right">
                <i class="fa fa-edit"></i> Edit
            </div>
            <div v-if="editable" @click="toggleEdit" class="btn btn-link btn-sm text-danger float-right">
                <i class="fa fa-ban"></i> Cancel
            </div>
        </template>
        <h6 class="heading-small text-muted mb-4">Account Information</h6>
        <div class="row">
            <div class="col-lg-12">
                <form-input
                    placeholder="Email" label="Email" ref="account.email"
                    v-model="account.email" disabled
                ></form-input>
            </div>
            <div class="col-lg-12">
                <form-select v-if="editable"
                    label="Status" placeholder="Status" ref="account.status"
                    v-model="account.status" :options="statuses"
                ></form-select>
                <form-input v-else
                    label="Status" placeholder="Status" capitalize
                    v-model="account.status" :disabled="!editable"
                ></form-input>
            </div>
        </div>
        <div v-if="editable" class="row">
            <div class="col-sm-12 text-right">
                <button @click="save" type="button" class="btn btn-warning btn-rounded long">
                    <i class="fa fa-save mr-1"></i> Save
                </button>
            </div>
        </div>
    </form>
</template>

<script>
import mixins from 'utils/mixins';

export default {
    name: "AccountForm",

    data: () => ({
        editable: false,
        originalAccount: {},
        account: {
            email: '',
            status: '',
        }
    }),

    methods: {
        
        initAccount() {
            this.account = {...this.$store.getters.user};
        },

        toggleEdit() {
            (this.editable = !this.editable)
                ? this.originalAccount = {...this.account}
                : this.account = {...this.originalAccount};
        },

        async save() {
            if (!(await this.confirm("Are you sure you want to edit this data?", "")).value) {
                return;
            }
            this.$store.commit('setAccount', this.account);
            this.$store.dispatch('saveAccount')
                .then(response => this.savedSuccessfully(response))
                .catch(error => this.saveFailed(error));
        },
        
        savedSuccessfully(response) {
            this.promptSuccess(response.data.message);
            this.editable = false;
            this.initAccount();
        },
        
        saveFailed(error) {
            this.promptFormErrors(this.$refs, error);
        },
    },

    mixins: [ mixins ],

    props: {
        statuses: Array,
        isCurrentUser: Boolean,
    },

    mounted() {
        setTimeout(() => this.initAccount(), 1000);
    },
}
</script>