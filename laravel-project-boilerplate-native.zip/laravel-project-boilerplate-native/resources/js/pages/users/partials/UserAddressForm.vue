<template>
    <form @submit.prevent="">
        <div v-if="!editable" @click="toggleEdit" class="btn btn-link btn-sm text-primary float-right">
            <i class="fa fa-edit"></i>
            Edit
        </div>
        <div v-if="editable && !isRequesting" @click="toggleEdit" class="btn btn-link btn-sm text-danger float-right">
            <i class="fa fa-ban"></i>
            Cancel
        </div>
        <h6 class="heading-small text-muted mb-4">Address Information</h6>
        <div class="row">
            <div class="col-lg-6">
                <google-map v-if="initialized" @change="syncMapData" :disabled="!editable"
                    :initial-value="initialAddress" :initial-location="initialAddress.position" ></google-map>
            </div>
            <div class="col-lg-6">
                <div class="row">
                    <div class="col-lg-10">
                        <form-input
                            placeholder="Unit/House no, Building, Street name"
                            label="Unit/House no, Building, Street name"
                            v-model="address.unit_no"
                            ref="unit_no"
                            :disabled="!editable"
                        ></form-input>
                    </div>
                    <div class="col-lg-12">
                        <form-input
                            label="Barangay"
                            placeholder="Barangay"
                            v-model="address.barangay"
                            ref="barangay"
                            :disabled="!editable"
                        >
                        </form-input>
                    </div>
                    <div class="col-lg-12">
                        <form-input
                            placeholder="City/Municipality"
                            label="City/Municipality"
                            v-model="address.town"
                            ref="town"
                            :disabled="!editable"
                        ></form-input>
                    </div>
                    <div class="col-lg-12">
                        <form-input
                            placeholder="Province"
                            label="Province"
                            v-model="address.province"
                            ref="province"
                            :disabled="!editable"
                        ></form-input>
                    </div>
                    <div class="col-lg-6">
                        <form-input
                            placeholder="Zipcode"
                            label="Zipcode"
                            v-model="address.zipcode"
                            ref="zipcode"
                            :disabled="!editable"
                        ></form-input>
                    </div>
                </div>
            </div>
        </div>
        <div v-if="editable" class="row">
            <div class="col-sm-12 text-right">
                <button v-if="!isRequesting" type="submit" class="btn btn-warning btn-rounded long"  @click="save">
                    <i class="fa fa-save mr-1"></i> Save
                </button>
                <button v-else disabled class="disabled btn btn-warning btn-rounded long">
                    <i class="fa fa-spinner fa-spin mr-2"></i> Please wait
                </button>
            </div>
        </div>
    </form>
</template>
<script>
import mixins from 'utils/mixins';

export default {
    name: "UserAddressForm",

    computed: {
        initialAddress() {
            return {
                address: { ...this.address },
                position: {
                    lat: parseFloat(this.address.lat || 0),
                    lng: parseFloat(this.address.lng || 0),
                }
            };
        },
    },

    data: () => ({
        initialized: false,
        editable: false,
        originalAddress: {},
        address: {
            id: '',
            unit_no: '',
            street: '',
            barangay: '',
            town: '',
            province: '',
            zipcode: '',
        },
        isRequesting: false,
    }),

    methods: {
        initAddress() {
            this.address = this.$store.getters.address;
            this.initialized = true;
        },
        
        syncMapData(payload) {
            this.address.barangay = payload[0].address.barangay;
            this.address.town = payload[0].address.city;
            this.address.country = payload[0].address.country;
            this.address.lat = payload[0].position.lat;
            this.address.lng = payload[0].position.lng;
            this.address.province = payload[0].address.province;
            this.address.zipcode = payload[0].address.postal_code;
        },

        toggleEdit() {
            (this.editable = !this.editable)
                ? this.originalAddress = {...this.address}
                : this.address = {...this.originalAddress};
        },

        async save() {
            if (!(await this.confirm("Are you sure you want to edit this data?", "")).value) {
                return;
            }
            this.isRequesting = true;
            this.$store.commit('setAddress', this.address);
            this.$store.dispatch('saveAddress')
                .then(response => this.savedSuccessfully(response))
                .catch(error => this.saveFailed(error))
                .finally(() => this.isRequesting = false);
        },
        
        savedSuccessfully(response) {
            this.promptSuccess(response.data.message);
            this.editable = false;
            this.initAddress();
        },
        
        saveFailed(error) {
            this.promptFormErrors(this.$refs, error);
        },

    },

    mixins: [ mixins ],

    mounted() {
        setTimeout(() => this.initAddress(), 1000);
    },
}
</script>
