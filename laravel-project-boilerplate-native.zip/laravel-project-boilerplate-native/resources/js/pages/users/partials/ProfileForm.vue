<template>
    <form @submit.prevent="">
        <div v-if="!editable" @click="toggleEdit" class="btn btn-link btn-sm text-primary float-right">
            <i class="fa fa-edit"></i> Edit
        </div>
        <div v-if="editable && !isRequesting" @click="toggleEdit" class="btn btn-link btn-sm text-danger float-right">
            <i class="fa fa-ban"></i> Cancel
        </div>
        <h6 class="heading-small text-muted mb-4">Personal Information</h6>
        <div class="row">
            <div class="col-lg-9">
                <form-input
                    placeholder="Last name"
                    label="Last name"
                    v-model="profile.lastname"
                    ref="lastname"
                    :disabled="!editable"
                ></form-input>
            </div>
            <div class="col-lg-3">
                <form-input
                    placeholder="Suffix"
                    label="Suffix"
                    v-model="profile.suffix"
                    ref="suffix"
                    :disabled="!editable"
                ></form-input>
            </div>
            <div class="col-lg-6">
                <form-input
                    placeholder="First name"
                    label="First name"
                    v-model="profile.firstname"
                    ref="firstname"
                    :disabled="!editable"
                ></form-input>
            </div>
            <div class="col-lg-6">
                <form-input
                    placeholder="Middle name"
                    label="Middle name"
                    v-model="profile.middlename"
                    ref="middlename"
                    :disabled="!editable"
                ></form-input>
            </div>
            <div class="col-lg-8">
                <form-date-picker
                    v-if="editable"
                    label="Birthdate"
                    v-model="profile.birthdate"
                    ref="birthdate"
                    format="MMMM DD, YYYY"
                ></form-date-picker>
                <form-input
                    v-else
                    placeholder="Birthdate"
                    label="Birthdate"
                    :value="formatedBirthdate"
                    :disabled="!editable"
                ></form-input>
            </div>
            <div class="col-lg-6">
                <form-select 
                    v-if="editable"
                    :options="genders"
                    label="Sex"
                    placeholder="Sex"
                    v-model="profile.gender"
                    ref="profile.gender"
                    :allow-empty="!isAdmin"
                >
                </form-select>
                <form-input
                    v-else
                    capitalize
                    placeholder="Sex"
                    label="Sex"
                    v-model="profile.gender"
                    :disabled="!editable"
                ></form-input>
            </div>
            <div class="col-lg-6">
                <form-select 
                    v-if="editable"
                    :options="civilStatus"
                    label="Civil Status"
                    placeholder="Civil Status"
                    v-model="profile.civil_status"
                    ref="profile.civil_status"
                    :allow-empty="!isAdmin"
                >
                </form-select>
                <form-input
                    v-else
                    placeholder="Civil Status"
                    label="Civil Status"
                    v-model="profile.civil_status"
                    capitalize
                    :disabled="!editable"
                ></form-input>
            </div>
        </div>
        <div v-if="editable" class="row">
            <div class="col-sm-12 text-right">
                <button v-if="!isRequesting" type="submit" @click="save" class="btn btn-warning btn-rounded long">
                    <i class="fa fa-save mr-1"></i> Save
                </button>
                <button v-else disabled class="disabled btn btn-warning btn-rounded long">
                    <i class="fas fa-spin fa-spinner mr-2"></i> Please wait
                </button>
            </div>
        </div>
    </form>
</template>

<script>
import mixins from 'utils/mixins';

export default {
    name: "ProfileForm",

    computed: {
        formatedBirthdate() {
            return moment(this.profile.birthdate).format('MMMM DD, YYYY')
        }
    },

    data: () => ({
        editable: false,
        originalProfile: {},
        profile: {
            firstname: '',
            middlename: '',
            lastname: '',
            suffix: '',
            birthdate: '',
            gender: '',
            civil_status: '',
        },
        isRequesting: false,
    }),

    methods: {
        
        initProfile() {
            this.profile = {...this.$store.getters.profile};
        },

        toggleEdit() {
            (this.editable = !this.editable)
                ? this.originalProfile = {...this.profile}
                : this.profile = {...this.originalProfile};
        },
        

        async save() {
            if (!(await this.confirm("Are you sure you want to edit this data?", "")).value) {
                return;
            }
            this.isRequesting = true;
            this.$store.commit('setProfile', this.profile);
            this.$store.dispatch('saveProfile')
                .then(response => this.savedSuccessfully(response))
                .catch(error => this.saveFailed(error))
                .finally(() => this.isRequesting = false);
        },
        
        savedSuccessfully(response) {
            this.promptSuccess(response.data.message);
            this.editable = false;
            this.initProfile();
        },
        
        saveFailed(error) {
            this.promptFormErrors(this.$refs, error);
        },
    },

    mixins: [ mixins ],

    props: {
        genders: Array,
        civilStatus: Array,
        isAdmin: {
            default: false,
            type: Boolean,
        },
    },

    mounted() {
        setTimeout(() => this.initProfile(), 1000);
    },
}
</script>