<template>
    <div class="row" >
        <div class="col-sm-12 text-right mb--5" style="z-index: 2;">
            <button type="button" @click="edit" class="btn btn-link btn-sm text-primary">
                <i class="fa fa-edit"></i>
                Edit
            </button>
            <button type="button" @click="destroy" class="btn btn-link btn-sm text-danger">
                <i class="fa fa-trash"></i>
                Delete
            </button>
        </div>
        <div class="col-lg-4">
            <form-input
                placeholder="Contact Name"
                label="Contact Name"
                v-model="contact.name"
                :disabled="true"
            ></form-input>
        </div>
        <div class="col-lg-8">
            <form-input
                placeholder="Contact No."
                label="Contact No."
                v-model="contact.number"
                :disabled="true"
            ></form-input>
        </div>
    </div>
</template>
<script>
import mixins from 'utils/mixins';

export default {
    name: 'ContactForm',

    props: { contact: Object|Array },

    methods: {
        edit(event) {
            this.$store.commit('initializeUpdateContactForm', this.contact.id);
        },

        async destroy(event) {
            if (!(await this.confirm("Are you sure you want to delete this data?", "")).value) {
                return;
            }
            this.$store.dispatch('deleteContact', this.contact.id)
                .then(response => this.deleted(response))
                .catch(error => this.deleteFailed(error));
        },

        deleted(response) {
            this.promptSuccess(response.data.message);
        },

        deleteFailed(error) {
            this.promptErrors(error.response.data.message);
        }

    },

    mixins: [ mixins ],
}
</script>