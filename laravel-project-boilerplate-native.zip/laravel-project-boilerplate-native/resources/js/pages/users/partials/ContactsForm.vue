<template>
    <div>      
        <h6 class="heading-small text-muted mb-4">Contact information</h6>
        
        <contact-form v-for="(contact, key) in contacts" :key="key" :contact="contact">
        </contact-form>

        <div class="row">
            <div class="col-sm-12">
                <button type="button" @click="addContactForm" class="btn btn-warning btn-rounded long float-right">
                    <i class="fa fa-plus"></i>
                    Add New Contact
                </button>
            </div>
        </div>
        <contact-modal-form></contact-modal-form>
    </div>
</template>
<script>
import mixins from 'utils/mixins';

const ContactForm = () => import('./ContactForm');
const ContactModalForm = () => import('./ContactModalForm');

export default {
    name: 'ContactsForm',

    components: { ContactForm, ContactModalForm },

    data: () => ({
        editable: false,
        contacts: [],
    }),

    methods: {
        addContactForm(event) {
            this.$store.commit('initializeCreateContactForm');
        },

        initContacts() {
            this.contacts = this.$store.getters.contacts;
        },

        toggleEdit() {
            this.editable = !this.editable;
        },

        async save() {
            if (!(await this.confirm("Are you sure you want to edit this data?", "")).value) {
                return;
            }
            this.$store.commit('setContacts', this.contacts);
            this.$store.dispatch('saveContacts')
                .then(response => this.savedSuccessfully(response))
                .catch(error => this.saveFailed(error));
        },
        
        savedSuccessfully(response) {
            this.promptSuccess(response.data.message);
            this.editable = false;
            this.initContacts();
        },
        
        saveFailed(error) {
            console.error(error);
        },
    },

    mixins: [ mixins ],

    mounted() {
        setTimeout(() => this.initContacts(), 1000);
    },
}
</script>
