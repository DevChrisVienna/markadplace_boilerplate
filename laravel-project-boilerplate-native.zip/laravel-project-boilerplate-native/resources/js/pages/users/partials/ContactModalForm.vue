<template>
    <modal :title="title" v-model="modalShown" @hidden="onHide">
        <form class="row" @submit.prevent="">
            <div class="col-lg-8">
                <form-input
                    placeholder="Contact Name"
                    label="Contact Name"
                    v-model="contact.name"
                    ref="name"
                ></form-input>
            </div>
            <div class="col-lg-10">
                <form-input
                    placeholder="Contact No."
                    label="Contact No."
                    v-model="contact.number"
                    ref="number"
                ></form-input>
            </div>
            <div class="col-lg-12">
                <button v-if="!isRequesting" button="button" @click="save" class="btn btn-warning btn-rounded long">
                    <i class="fa fa-save pr-1"></i> Save
                </button>
                <button v-else button="button" disabled class="disabled btn btn-warning btn-rounded long">
                    <i class="fa fa-spinner fa-spin mr-2"></i> Please wait
                </button>
            </div>
        </form>
    </modal>
</template>
<script>
import mixins from 'utils/mixins';

export default {
    name: 'ContactModalForm',

    computed: {
        title() {
            return this.isCreate
                ? "Add a contact no."
                : "Update a contact no.";
        },

        formData() {
            return this.$store.getters.contactFormData;
        },

        isCreate() {
            return !this.contact.id;
        }

    },

    data: () => ({
        modalShown: false,
        clearModal: true,
        contact: {},
        isRequesting: false,
    }),

    methods: {
        onHide() {
            if (!this.clearModal) {
                return;
            }
            this.isRequesting = false,
            this.$store.commit('clearContactForm');
        },

        async save(event) {
            event.preventDefault();
            this.clearModal = this.modalShown = false;
            if (!(await this.confirm("Are you sure you want to edit this data?", "")).value) {
                this.clearModal = this.modalShown = true;
                return;
            }
            this.isRequesting = this.clearModal = this.modalShown = true;
            let action = this.isCreate ? 'addContact' : 'updateContact';

            this.$store.dispatch(action)
                .then(response => this.savedSuccessfully(response))
                .catch(error => this.saveFailed(error))
                .finally(() => this.isRequesting = false);
        },
        
        savedSuccessfully(response) {
            this.promptSuccess(response.data.message);
        },
        
        saveFailed(error) {
            this.promptFormErrors(this.$refs, error);
        },

        toggleContactForm() {
            this.modalShown = !!Object.keys(this.contact).length;
        },

        clearFieldErrors() {
            this.$refs.name.clearError();
            this.$refs.number.clearError();
        },

        initializeFormData() {
            this.clearFieldErrors();
            this.contact = this.formData;
            this.toggleContactForm();
        },

    },

    watch: {
        formData(newValue) {
            this.initializeFormData();
        }
    },

    mixins: [ mixins ],
}
</script>