<script>
import mixins from 'utils/mixins';

import store from './store/UserFormStore/store';
import Form from 'models/components/Form';
import User from 'models/users/User';

import AccountForm from 'pages/users/partials/AccountForm';
import ProfileForm from 'pages/users/partials/ProfileForm';
import UserAddressForm from 'pages/users/partials/UserAddressForm';
import ChangePasswordForm from 'pages/users/partials/ChangePasswordForm';
import ContactsForm from 'pages/users/partials/ContactsForm';
import ContactForm from 'pages/users/partials/ContactForm';

export default {
    name: 'UserForm',
    components: {
        AccountForm, ProfileForm, UserAddressForm, ContactsForm, ContactForm,
        ChangePasswordForm,
    },

    data: () => ({
        displayImage: {},
        form: new Form({
            account: {
                email: '',
                password: '',
                confirm_password: '',
                name: '',
                firstname: '',
                middlename: '',
                lastname: '',
                suffix: '',
                birthdate: moment().format('YYYY-MM-DD'),
                gender: '',
                status: '',
                display_image: "user-default.png"
            },
            contacts: [{
                name: '',
                number: '',
            }],
            address: {
                unit_no: '',
                street: '',
                barangay: '',
                town: '',
                province: '',
                zipcode: '',
                lat: 0.0,
                lng: 0.0,
                place_id: 0,
            },
        }),
        model: {},
    }),
    methods: {
        
        deleteSuccess() {
            this.redirect(this.deleteRedirectRoute, {}, 3000);
        },

        updateDisplayImage(payload) {
            this.displayImage.sendPatch(route(
                'api.backend.users.update-image',
                this.user.id
            ))
                .then(response => this.updatedDisplayImage(response))
                .catch(error => this.updateDisplayImageFailed(error));
        },

        updatedDisplayImage(response) {
            this.promptSuccess(response.data.message);
        },
        
        updateDisplayImageFailed(error) {
            const { response } = error;
            this.promptErrors(response.data.message);
        },

        async confirmRequestWithPin(message) {
            return (await this.confirmWithPin(message)).value;
        }

    },
    mixins: [ mixins ],
    
    props: {
        user: Object|Array,
        deleteRedirectRoute: {
            type: String,
            required: true,
        }
    },

    store,

    mounted() {
        this.model = new User(this.user);
        this.$store.commit('initializeUser', this.model.getData());
        this.form = this.$store.getters.user;
        this.displayImage = new Form({
            image: this.form.display_image,
        });
    }
}
</script>