<script>
import mixins from 'utils/mixins';
import Form from 'models/components/Form';

export default {
    name: 'PlayerCreateForm',

    data: () => ({
        form: new Form({
            account: {
                email: "",
                password: "",
                password_confirmation: "",
                name: "",
                firstname: "",
                middlename: "",
                lastname: "",
                suffix: "",
                birthdate: moment().format('YYYY-MM-DD'),
                gender: "",
                civil_status: "",
                display_image: null,
            },
            contacts: [{
                name: '',
                number: '',
            }],
            address: {
                unit_no: '',
                street: '',
                barangay: '',
                town: '',
                province: '',
                zipcode: '',
                last: 0.0,
                lng: 0.0,
                place_id: 0,
            },
        }),
    }),
    methods: {

        async save(event) {
            event.preventDefault();
            if (!(await this.confirm("Are you sure you want to save this data?", "")).value) {
                return;
            }

            this.form.sendPost(route('api.backend.players.store'))
                .then(response => this.saved(response))
                .catch(error => this.failedToSave(error));
        },
        
        saved(response) {
            this.refreshOrRedirect(
                response.data.message.message,
                "Do you want to add another player?",
                route('pages.players.index'),
                'success'
            );
        },
        
        failedToSave(error) {
            this.promptFormErrors(this.$refs, error);
        },

    },
    mixins: [ mixins ],

    props: {
        genders: Array,
        civilStatus: Array,
    }
}
</script>