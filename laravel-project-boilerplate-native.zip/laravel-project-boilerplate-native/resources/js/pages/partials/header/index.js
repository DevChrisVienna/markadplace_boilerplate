// export { default as NotificationBadge } from './NotificationBadge.vue';
export const NotificationBadge = () => import('./NotificationBadge.vue');