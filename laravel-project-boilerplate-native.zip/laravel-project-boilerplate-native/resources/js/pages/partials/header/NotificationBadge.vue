<script>
import { bus } from 'utils/bus';

export default {
    name: 'NotificationBadge',

    computed: {
        hasNewNotificaiton() {
            return this.newNotificationCount > 0;
        },
    },

    data: () => ({
        newNotificationCount: 0,
        previousNotificationCount: 0,
    }),

    methods: {

        readAll() {
            axios.get(route('api.backend.notifications.read-all'))
                .then(response => this.markAllAsRead(response))
                .catch(error => this.failedToReadAll(error))
        },

        markAllAsRead(response) {
            this.$refs.notificationsList.records.forEach(notification => {
                if (notification.read_at == null) {   
                    notification.read_at = moment();
                }
            });
        },

        failedToReadAll(error) {
            this.promptErrors(error.message);
        },
        
        isDropDownVisible() {
            return $(this.$refs.dropdown).offsetParent != null
        },

        isUnread(notification) {
            return notification.read_at == null;
        },

        notificationItemClass(notification) {
            return {
                'bg-light-gray': this.isUnread(notification),
            }
        },

        toggleDropDown() {
            if (!this.isDropDownVisible()) {
                return;
            } else if (this.hasNewNotificaiton) {
                this.$refs.notificationsList.refreshTable();
            }
            this.clearUnread();
        },

        clearUnread() {
            this.newNotificationCount = 0;
        },

        recievedNotification(notification) {
            this.newNotificationCount += 1;
            if (this.isDropDownVisible()) {
                this.$refs.notificationsList.refreshTable();
            }
        },

        notificationsLoaded(records) {
            if (this.previousNotificationCount == 0) {
                this.newNotificationCount = records
                    .filter(notification => this.isUnread(notification))
                    .length;
            }
            this.previousNotificationCount = records.length;
        }

    },

    mounted() {
        bus.$on('notification-recieved', notification => this.recievedNotification(notification));
    },


}
</script>