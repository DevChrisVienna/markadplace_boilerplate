<template>
    <div id="main-sidebar">
        <slot></slot>
    </div>
</template>

<script>
    import { mixins } from 'utils'
    import { default as SidebarItem } from './SidebarItem.vue'

    export default {
        name: "Sidebar",
        mixins: [ mixins ],
        components: { SidebarItem },
        data: () => ({

        }),
    }
</script>