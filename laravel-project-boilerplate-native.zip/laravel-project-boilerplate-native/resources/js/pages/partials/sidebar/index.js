// export { default as Sidebar } from './Sidebar.vue';
// export { default as SidebarItem } from './SidebarItem.vue'
export const Sidebar = () => import('./Sidebar.vue');
export const SidebarItem = () => import('./SidebarItem.vue');