<template>
    <li :class="styleClass.listItem">
        <a :href="route"
            @click="toggleCollapse"
            :class="styleClass.linkItem"
        >
            <i :class="iconClasses"></i>
            <span v-text="title"></span>
            <i v-if="hasNested" class="fa fa-angle-down drop fax-lg"></i>
        </a>
        <div :id="subListId" ref="subList">
            <slot></slot>
        </div>
    </li>
</template>
<script>
export default {
    name: 'SidebarItem',
    components: {},
    props: {
        route: String,
        icon: String,
        title: String,
        active: {
            default: false,
            type: Boolean,
        },
        nested: {
            default: false,
            type: Boolean,
        },
        expanded: {
            default: false,
            type: Boolean,
        },
    },
    computed: {
        hasIcon() {
            return !!this.icon
        },
        hasNested() {
            return !!this.nested
        },
        iconClasses() {
            return `fa fa-lg pr-2 ${ this.icon }`
        },
        isListShown() {
            return this.hasNested && this.isExpanded
        },
        subListId() {
            return `sidebar-item-sublist-${ this._uid }`
        },
        styleClass() {
            return {
                listItem: {
                    'active': this.isActive,
                    'nav-item': true,
                },
                linkItem: {
                    'is-expanded': this.isExpanded,
                    'nav-link': true,
                },
            }
        }
    },
    data: () => ({
        isExpanded: false,
        isActive: false,
    }),
    methods: {
        toggleCollapse(event) {
            if ($(event.target).parents('li').children('a').attr('href') !== '#') {
                return;
            }
            event.preventDefault();
            this.slideToggleSubItems();
        },
        slideToggleSubItems() {
            $(`#${ this.subListId } > *`).slideToggle(
                event ? 500 : 0,
                () => (this.isExpanded = !this.isExpanded)
            )
        }
    },
    mounted() {
        this.isActive = this.active
        this.isExpanded = this.expanded
    }
}
</script>