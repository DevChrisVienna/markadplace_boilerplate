<template>
    <li>
        <a href="#" class="tooltiped"
            @click.prevent="() => $refs.uploader.click()" 
            data-toggle="tooltip"
            :data-title="label">
            <i :class="icon"></i>
        </a>
        <input hidden type="file" ref="uploader" @change="upload" />
    </li>
</template>
<script>
import mixins from 'utils/mixins';
import Form from 'models/components/Form'

export default {
    name: "UploadActionButton",
    data: () => ({
        uploadForm: new Form({
            excel: []
        }),

    }),
    methods: {
        upload() {
            if (!this.$refs.uploader.files.length) {
                return;
            }
            this.uploadForm.excel = Form.fileListToArray(this.$refs.uploader.files);
            this.uploadForm.send(this.method, this.link, true)
                .then(response => this.prepareQueue(response.data))
                .catch(error => this.promptErrors(error.response.data.message));
        },
        prepareQueue(response) {
            this.$emit('success', response);
        }
    },

    mixins: [mixins],

    props: {
        icon: String,
        label: String,
        link: String,
        method: {
            type: String, 
            default: "get",
        },
    },

    mounted() {
        this.initTooltip();
    }
}
</script>