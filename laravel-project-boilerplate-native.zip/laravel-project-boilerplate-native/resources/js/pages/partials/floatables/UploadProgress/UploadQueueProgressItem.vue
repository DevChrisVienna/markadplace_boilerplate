<template>
    <a :href="link" class="item">
        <div class="row">
            <div class="col-1 icon-container text-black-50"><i class="fa fas fa-file"></i></div>
            <div class="col-sm-11 col-md-8 pt-1">
                <div class="filename" v-text="title"></div>
                <div class="loading-bar"><div :class="progressValue.class" :style="progressValue.style"></div></div>
            </div>
            <div class="col-md-3 col-12 remarks text-right">
                <div class="text-success">
                    <i style="width=20px;" class="fas fa-check-circle"></i>
                    <span v-text="completedCount"></span>
                </div>
                <div class="text-danger">
                    <i style="width=20px;" class="fas fa-exclamation-triangle"></i>
                    <span v-text="failedCount"></span>
                </div>
            </div>
        </div>
    </a>
</template>
<script>
export default {
    name: 'UploadQueueProgressItem',
    computed: {
        title() {
            return `${ this.fileUpload.filename } - ${ this.percentage }%`;
        },
        progressValue() {
            return {
                style: `width: ${ this.percentage }%;`,
                class: {
                    'bg-success': this.percentage == 100,
                    'value': true,
                }
            }
        },
        percentage() {
            return this.fileUpload.percentage;
        },
        completedCount() {
            return this.fileUpload.completedCount || 0;
        },
        failedCount() {
            return this.fileUpload.failedCount || 0;
        },
    },
    data() {
        return {
            link: route(this.fileUpload.route_name, JSON.parse(this.fileUpload.route_params)),
        }
    },
    props: {
        fileUpload: Object|Array,
    }
}
</script>
