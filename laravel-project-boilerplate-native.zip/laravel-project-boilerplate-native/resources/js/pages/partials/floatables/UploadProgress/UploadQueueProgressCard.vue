<template>
    <div v-if="hasFileUploads" :class="uploadQueueProgressClass">
        <div class="card-header">
            <a class="card-link collapsed" data-toggle="collapse" aria-expanded="false" href="#upload-queue-card-body">
                <i class="fa fas fa-upload mr-2"></i>
                <span class="font-weight-bold" v-text="cardTitle"></span>
                <i class="fa fas fa-angle-down drowpdown"></i>
            </a>
        </div>
        <div id="upload-queue-card-body" class="collapse" data-parent="#floatables">
            <div class="card-body">
                <upload-queue-progress-item
                    v-for="(uploadFile, key) in fileUploads" :key="key"
                    :file-upload="uploadFile"
                >
                </upload-queue-progress-item>
            </div>
        </div>
    </div>
    <div v-else style="height: 46px !important;"></div>
</template>
<script>
import { bus } from 'utils/bus';
const UploadQueueProgressItem = () => import('./UploadQueueProgressItem.vue');

export default {
    name: "UploadQueueProgressCard",
    components: { UploadQueueProgressItem },
    computed: {
        cardTitle() {
            return `Uploading ${ this.fileUploads.length } files`
        },

        hasFileUploads() {
            return this.fileUploads.length !== 0;
        },
        uploadQueueProgressClass() {
            return {
                'card': true,
                'upload-queue-progress-card': true,
                'empty': !this.hasFileUploads,
            }
        },
    },

    data: () => ({
        fileUploads: [],
    }),

    methods: {
        fetchUploadFiles() {
            axios.get(route('api.backend.file-uploads.index'))
                .then(response => this.mapFileUploads(response.data))
                .catch(error => this.promptErrors(error.message));
        },
        mapFileUploads(response) {
            this.fileUploads = response.data.fileUploads;
        },
        initializeListeners() {
            bus.$on('upload-progressed', (data) => this.updateQueues(data.fileUpload))
        },
        updateQueues(fileUpload) {
            let isOldData = null;
            this.fileUploads = this.fileUploads
                .map(item => item.id === fileUpload.id ? isOldData = fileUpload : item)
            if (isOldData == null) {
                this.fileUploads.push(fileUpload);
            }
        }
    },

    mounted() {
        this.fetchUploadFiles();
        this.initializeListeners();
    }
}
</script>